package com.example.number_guess;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private int randomNumber;
    private EditText editText;
    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI elements
        editText = findViewById(R.id.editText);
        Button checkButton = findViewById(R.id.checkButton);
        Button restartButton = findViewById(R.id.restartButton);
        textView = findViewById(R.id.textView);

        // Generate random number between 1 and 100
        Random rand = new Random();
        randomNumber = rand.nextInt(100) + 1;

        // Set click listeners
        checkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkGuess();
            }
        });

        restartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                restartGame();
            }
        });
    }

    private void checkGuess() {
        // Get user guess
        String guessText = editText.getText().toString();

        // Check if the guess is empty
        if (guessText.isEmpty()) {
            textView.setText("Please enter a guess");
            return;
        }

        // Parse the guess into an integer
        int guess = Integer.parseInt(guessText);

        // Compare the guess with the random number
        if (guess == randomNumber) {
            textView.setText("Congratulations! You guessed the correct number!");
        } else if (guess < randomNumber) {
            textView.setText("Too low! Try a higher number.");
        } else {
            textView.setText("Too high! Try a lower number.");
        }
    }

    private void restartGame() {
        // Generate new random number
        Random rand = new Random();
        randomNumber = rand.nextInt(100) + 1;

        // Clear the EditText and TextView
        editText.setText("");
        textView.setText("Welcome to number guess game");
    }
}
